<?php

namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use App\Repositories\Exceptions\OptimisticLockException;
use JWTAuth;
use App;
use DB;

class ProductController extends Controller {
    protected $user;
    protected $productService;

    public function __construct(Request $request)
    {
        $this->productService    =  app(App\Repositories\Services\ProductService::class);
        try {
            $this->user = JWTAuth::parseToken()->authenticate();
        } catch (TokenExpiredException $e) {
            $status = ['xx' => 'TokenExpiredException'];
            return response()->json(compact('status'));
        } catch (JWTException $e) {
           $status = ['xx' => 'JWTException'];
           return response()->json(compact('status'));
       }

   }
   public function listProduct(Request $request) {

    $products = Product::where('user_id', $this->user->id)->get();
    $user = $this->user;
    return response()->json(compact('products','user'));
}

public function add(Request $request) {
    $data = $request->all();
    $data['user_id'] = $this->user->id;
    if ($this->productService->addProduct($data)) {
        $json = ['status' => '200','message' => 'Add new ok'];
        return response()->json(compact('json'));
    }
    else {
        $json = ['status' => '500','message' => 'Add new not ok'];
        return response()->json(compact('json'));
    }
}

public function edit(Request $request) {
    $data = $request->all();

    try {
        DB::beginTransaction();
        $this->productService->editProduct($data, $this->user);
        $this->productService->updateVersionProduct($data);
        DB::commit();
        $json = ['status' => '200','message' => 'Edit OK'];
        return response()->json(compact('json'));

    } catch (OptimisticLockException $e) {
        DB::rollback();
        $json = ['status' => '500','message' => 'Edit not ok'];
        return response()->json(compact('json'));
    }

}

public function delete(Request $request) {
    $data = $request->all();
        //$data['user_id'] = $this->user->id;
    $product = Product::where('user_id' ,$this->user->id)->where('id',$data['id'])->first();
    if ($product) {
        $product->delete();
        $json = ['status' => '200','message' => 'delete ok'];
        return response()->json(compact('json'));
    }
    else {
        $json = ['status' => '500','message' => 'delete not ok'];
        return response()->json(compact('json'));
    }
}

}
