<?php
namespace App\Repositories\Services;

use DB;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Config;
use App\Repositories\Exceptions\OptimisticLockException;
use App\Models\Product;
/**
 * Course Service.
 */
class ProductService
{
    public function findProductId() {
        return "xxxx";
    }
    public function addProduct($data) {
        return Product::create($data);
    }
    public function editProduct($data, $user) {
        $product = Product::where('user_id' ,$user->id)->where('id',$data['id'])->first();
        if ($product) {
            return $product->update($data);
        }
    }
    public function updateVersionProduct($data)
    {
        $query = Product::query();
        $query->where('id', '=', $data['id']);
        $query->where('version_no', '=', $data['version_no']);
        $affectedRows = $query->update(array('version_no' =>$data['version_no'] + 1));
        if ($affectedRows === 0) {
            throw new OptimisticLockException();
        }
        return $affectedRows;
    }
}
