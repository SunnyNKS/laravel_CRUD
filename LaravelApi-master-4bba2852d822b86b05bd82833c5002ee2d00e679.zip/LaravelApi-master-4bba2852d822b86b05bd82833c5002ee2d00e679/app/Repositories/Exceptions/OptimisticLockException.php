<?php
namespace App\Repositories\Exceptions;

/**
 * Used when the optimistic lock failed.
 */
class OptimisticLockException extends \Exception
{
}
